package com.Group;

import java.awt.Image;

public class Cleric extends CharacterClass{

	public Cleric(int x, int y, String file, String[] action, int count, int duration, Rect[][] grid, Image image) {
		super(x, y, file, action, count, duration, grid, image);
		
		hp = 10;
		maxHp = hp;
		mp = 25;
		str = 0;
		def = 4;
		agl = 2;
		con = 9;
		intg = 15;
		wis = 15;
		exp = 0;
		lvl = 1;
		atkRng = 1;
		mvmRange = 5;
		this.image = image;
		
	}
	
}
